# SmartApp Backend

Сценарий голосового управления для CanvasApp «Сапёр».
